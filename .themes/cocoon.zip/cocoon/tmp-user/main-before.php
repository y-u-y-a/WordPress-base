<?php
//main手前に挿入するテンプレート
if ( !defined( 'ABSPATH' ) ) exit;
?>
