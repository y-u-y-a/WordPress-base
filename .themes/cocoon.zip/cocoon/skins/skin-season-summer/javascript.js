//ここにスキンで利用するJavaScriptを記入する
$('#footer').before('<div class="page-top"><a href="#container"><i class="fa fa-chevron-circle-up" aria-hidden="true"></i> PAGE TOP</a></div>');
// $( 'select' ).wrap( '<div class="select-box"></div>' );
$(function () {$('.date-tags').insertAfter('.entry-title');});
// $(function () {$('.blogcard-footer').remove();});
// $(function () {$('.entry-card .cat-label').remove();});
// $(function () {$('.related-entry-card .cat-label').remove();});
// $(function () {$('.carousel-entry-card .cat-label').remove();});

